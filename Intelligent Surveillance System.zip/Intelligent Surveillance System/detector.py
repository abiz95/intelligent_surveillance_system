import cv2,os
import sqlite3
import numpy as np
from PIL import Image 
import pickle
import time
import datetime

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('trainer/trainer.yml')
cascadePath = "Classifiers/face.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);
path = 'dataSet'

def getProfile(Id):
	conn=sqlite3.connect("facebase.db")
	cmd="SELECT * FROM people WHERE ID="+str(Id)
	cursor=conn.execute(cmd)
	profile=None
	for row in cursor:
		profile=row
	conn.close()
	return profile 


dt=datetime.datetime.now().strftime("%d-%m-%y")
tm=datetime.datetime.now().strftime("%H:%M")
cam = cv2.VideoCapture(0)
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi',fourcc, 4, (640,480))
font = cv2.FONT_HERSHEY_SIMPLEX #Creates a font
while True:
    ret, im =cam.read()
    gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    faces=faceCascade.detectMultiScale(gray, 1.2,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
        Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
        if(conf<60):
                profile=getProfile(Id)
        else:
                Id=0
                profile=getProfile(Id)
        if(profile!=None):
            cv2.rectangle(im, (x-22,y-90), (x+w+80, y-22), (0,255,0), -1)
            cv2.putText(im,str(profile[0]), (x,y-40), font, 2, (255,255,255), 3)
            cv2.putText(im,str(profile[1]), (x+50,y-40), font, 2, (255,255,255), 3)
            connt=sqlite3.connect("facebase.db")
            c=connt.cursor()
            c.execute('''INSERT INTO detected(Id, name, Date, Time)
                  VALUES(?,?,?,?)''', (profile[0],profile[1], dt, tm))
            connt.commit()
            connt.close()

    out.write(im)
    cv2.imshow('Start',im) 
    if cv2.waitKey(10) & 0xFF==ord('q'):
        break
cam.release()
cv2.destroyAllWindows()








