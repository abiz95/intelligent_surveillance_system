from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
import os


def callback1():
    filename = 'dataSetGenerator.py'
    os.system(filename) #Open file [Same as Right-click Open]

def callback2():
    filename = 'trainer.py'
    os.system(filename) #Open file [Same as Right-click Open]

def callback3():
    filename = 'detector.py'
    os.system(filename) #Open file [Same as Right-click Open]

def callback4():
    filename = 'videox.py'
    os.system(filename) #Open file [Same as Right-click Open]

def callback5():
    filename = 'search.py'
    os.system(filename) #Open file [Same as Right-click Open]

 
root = Tk()
root.title("ISS")

text = Text(root)
frame = Frame(root)

img = ImageTk.PhotoImage(Image.open("123.jpg"))
panel = Label(root, image = img)
panel.pack(side = "top", fill = "both", expand = "yes", pady=5)

 
Button(frame, width=20, height=5, text="Add User", command=callback1).grid(row=3, column=0, padx=10, pady=10)
Button(frame, width=20, height=5, text="Train", command=callback2).grid(row=3, column=1, padx=10, pady=10)
Button(frame, width=20, height=5, text="Start", command=callback3).grid(row=3, column=2, padx=10, pady=10)
Button(frame, width=20, height=5, text="play", command=callback4).grid(row=3, column=3, padx=10, pady=10)
Button(frame, width=20, height=5, text="Search", command=callback5).grid(row=3, column=4, padx=10, pady=10)

frame.pack() 
root.mainloop()
