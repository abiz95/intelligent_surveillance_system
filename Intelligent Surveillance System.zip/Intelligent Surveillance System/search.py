from tkinter import *
import sqlite3

def connect():
    """Set up a connection with the database."""
    conn_obj = sqlite3.connect("facebase.db")
    cur_obj = conn_obj.cursor()
    conn_obj.commit()
    conn_obj.close()


def view():
    """View all database entries."""
    conn_obj = sqlite3.connect("facebase.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("SELECT * FROM detected")
    rows = cur_obj.fetchall()
    conn_obj.close()
    return rows


def search(date = "", time1 = "", time2 = ""):
    """Search for a database entry."""
    conn_obj = sqlite3.connect("facebase.db")
    cur_obj = conn_obj.cursor()
    cur_obj.execute("SELECT * "
                    "FROM detected "
                    "WHERE Date = ? AND Time BETWEEN ? AND ?", 
                    (date, time1, time2))
    rows = cur_obj.fetchall()
    conn_obj.close()
    return rows


def view_command():
    """View entries via button."""
    listing.delete(0, END)
    for row in view():
        listing.insert(END, row)


def search_command():
    """Search entry via button."""
    listing.delete(0, END)
    for row in search(t2_text.get(), 
                                t1_text.get(), 
                                t3_text.get() 
                                ):
        listing.insert(END, row)

def get_selected_row(event):
    """Pre-fill fields for selected entry."""
    global selected_tuple
    index = listing.curselection()[0]
    selected_tuple = listing.get(index)

    entry1.delete(0, END)
    entry1.insert(END, selected_tuple[1])

    entry2.delete(0, END)
    entry2.insert(END, selected_tuple[2])

    entry3.delete(0, END)
    entry3.insert(END, selected_tuple[3])

    entry4.delete(0, END)
    entry4.insert(END, selected_tuple[4])

window = Tk()

window.wm_title("Search")

# Labels for entry fields.
label1 = Label(window, text = "from")
label1.grid(row = 0, column = 0)

label2 = Label(window, text = "to")
label2.grid(row = 0, column = 2)

label3 = Label(window, text = "date")
label3.grid(row = 1, column = 0)



# Entry Fields.
t1_text = StringVar()
entry1 = Entry(window, textvariable = t1_text)
entry1.grid(row = 0, column = 1)

t3_text = StringVar()
entry2 = Entry(window, textvariable = t3_text)
entry2.grid(row = 0, column = 3)

t2_text = StringVar()
entry3 = Entry(window, textvariable = t2_text)
entry3.grid(row = 1, column = 1)



# List all data.
listing = Listbox(window, height = 6, width = 35)
listing.grid(row = 2, column = 0, rowspan = 6, columnspan = 2)

# Scrollbar.
scroller = Scrollbar(window)
scroller.grid(row = 2, column = 2, rowspan = 6)

# Configure scrollbar for Listbox.
listing.configure(yscrollcommand = scroller.set)
scroller.configure(command = listing.yview)

listing.bind('<<ListboxSelect>>', get_selected_row)

# Buttons for various operations on data.
button1 = Button(window, 
                text = "View All", 
                width = 12, 
                command = view_command)
button1.grid(row = 2, column = 3)

button2 = Button(window, 
                text = "Search Entry", 
                width = 12, 
                command = search_command)
button2.grid(row = 3, column = 3)


button6 = Button(window, 
                text = "Close", 
                width = 12, 
                command = window.destroy)
button6.grid(row = 7, column = 3)

# Keep window open until closed.
window.mainloop()
