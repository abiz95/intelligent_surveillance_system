import cv2
import sqlite3
from PIL import Image 
import pickle
from tkinter import *
import os


class Application(Frame):

    def __init__(self,master):
        super(Application, self).__init__(master)#Set __init__ to the master class
        self.grid()
        self.create_main()#Creates function

    def create_main(self):
        self.title = Label(self, text=" Enter ID and Name ")#TITLE 
        self.title.grid(row=0, column=2)

        self.user_entry_label = Label(self, text="ID: ")#ID LABEL
        self.user_entry_label.grid(row=1, column=1)

        self.user_entry = Entry(self)                        #ID ENTRY BOX
        self.user_entry.grid(row=1, column=2)

        self.pass_entry_label = Label(self, text="Name: ")#Name LABEL
        self.pass_entry_label.grid(row=2, column=1)

        self.pass_entry = Entry(self)                        #Name ENTRY BOX
        self.pass_entry.grid(row=2, column=2)

        self.sign_in_butt = Button(self, text="Next",command = self.main)#Next BUTTON
        self.sign_in_butt.grid(row=5, column=2)

    def main(self):
        cam = cv2.VideoCapture(0)
        detector=cv2.CascadeClassifier('Classifiers/face.xml')
        i=0
        count=0
        offset=50
        id= self.user_entry.get()
        name=self.pass_entry.get()
        conn=sqlite3.connect("facebase.db")
        cmd="SELECT * FROM people WHERE ID="+str(id)
        cursor=conn.execute(cmd)
        isRecordExit=0
        for row in cursor:
            isRecordExit=1
        if(isRecordExit==1):
            cmd="UPDATE people SET name="+str(name)+"WHERE ID="+str(id)
        else:
            cmd="INSERT INTO people(ID,Name) Values("+str(id)+","+str(name)+")"
        conn.execute(cmd)
        conn.commit()
        conn.close()

        while True:
            ret, im =cam.read()
            gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
            faces=detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(100, 100), flags=cv2.CASCADE_SCALE_IMAGE)
            for(x,y,w,h) in faces:
                count += 1
                i=i+1
                cv2.imwrite("dataSet/face-"+str(id) +'.'+ str(i) + ".jpg", gray[y-offset:y+h+offset,x-offset:x+w+offset])
                cv2.rectangle(im,(x-50,y-50),(x+w+50,y+h+50),(225,0,0),2)
                cv2.imshow('im',im[y-offset:y+h+offset,x-offset:x+w+offset])
                cv2.waitKey(100)
            if i>100:
                cam.release()
                cv2.destroyAllWindows()
                break
        print("complete")

#Main
root = Tk()
root.title("Add User")
root.geometry("400x100")

app = Application(root)#The frame is inside the widgit
root.mainloop()#Keeps the window open/running

