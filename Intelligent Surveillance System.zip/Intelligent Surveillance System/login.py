from tkinter import *
import os

class Application(Frame):
    def __init__(self,master):
        super(Application, self).__init__(master)#Set __init__ to the master class
        self.grid()
        self.create_main()#Creates function

    def create_main(self):
        self.title = Label(self, text=" Enter username and password ")#TITLE 
        self.title.grid(row=0, column=2)

        self.user_entry_label = Label(self, text="Username: ")#USERNAME LABEL
        self.user_entry_label.grid(row=1, column=1)

        self.user_entry = Entry(self)                        #USERNAME ENTRY BOX
        self.user_entry.grid(row=1, column=2)

        self.pass_entry_label = Label(self, text="Password: ")#PASSWORD LABEL
        self.pass_entry_label.grid(row=2, column=1)

        self.pass_entry = Entry(self, show='*')                        #PASSWORD ENTRY BOX
        self.pass_entry.grid(row=2, column=2)

        self.sign_in_butt = Button(self, text="Sign In",command = self.logging_in)#SIGN IN BUTTON
        self.sign_in_butt.grid(row=5, column=2)

    def logging_in(self):
        user_get = self.user_entry.get()#Retrieve Username
        pass_get = self.pass_entry.get()#Retrieve Password

        

        if user_get == 'admin' and pass_get == 'admin':
            filename = 'index.py'
            os.system(filename) #Open file [Same as Right-click Open]
            root.destroy

        else:
            
            r=Tk()
            r.title('Invalid')
            r.geometry('150x50')
            rlbl = Label(r, text='\n[!] Invalid Login')
            rlbl.pack()
            r.mainloop()






#Main
root = Tk()
root.title("Login")
root.geometry("400x100")
app = Application(root)#The frame is inside the widgit
root.mainloop()#Keeps the window open/running
